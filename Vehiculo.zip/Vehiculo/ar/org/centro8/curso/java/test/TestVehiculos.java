package ar.org.centro8.curso.java.test;
import ar.org.centro8.curso.java.entities.AutoClasico;
import ar.org.centro8.curso.java.entities.AutoNuevo;
import ar.org.centro8.curso.java.entities.Radio;

public class TestVehiculos {
    public static void main(String[] args) {
        Radio radio1 = new Radio("Mitre");
        Radio radio2 = new Radio("JBL");
        System.out.println("Proyecto vehiculos");
        System.out.println("----- AutoClasico sin radio -----");
        AutoClasico auto1 = new AutoClasico("Rosa", "VW", "Porche");
        System.out.println(auto1.toString());
        System.out.println("----- AutoClasico con radio -----");
        AutoClasico auto2 = new AutoClasico("Peugeot", "Mandarina", "Titan", radio1);
        System.out.println(auto2.toString());
        System.out.println("----- AutoClasico con precio, sin radio -----");
        AutoClasico auto3 = new AutoClasico("Gris", "VW", "208", 100000);
        System.out.println(auto3.toString());
        System.out.println("----- AutoClasico con precio y radio -----");
        AutoClasico auto4 = new AutoClasico("Yamaha", "Honda", "YBR", 50000, radio1);
        System.out.println(auto4.toString());
        System.out.println("----- AutoNuevo con precio y radio -----");
        AutoNuevo auto5 = new AutoNuevo("Marron", "Miller", "Torino", 10000, radio2);
        System.out.println(auto5.toString());
        System.out.println("----- AutoNuevo sin precio y con radio -----");
        AutoNuevo auto6 = new AutoNuevo("Morado", "VW", "Vento", radio2);
        System.out.println(auto6.toString());
        /*
         * NO SE PERMITE CREAR UN AUTO NUEVO SIN RADIO
         * System.out.println("----- Prueba AutoNuevo SIN radio -----");
         * AutoNuevo auto7=new AutoNuevo("Rojo", "Toyota", "Corolla");
         * System.out.println(auto7.toString());
         */

    }

}
