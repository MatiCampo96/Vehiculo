package ar.org.centro8.curso.java.entities;

public class AutoNuevo extends Vehiculo {
    public AutoNuevo(String color, String marca, String modelo, String marcaRadio) {
        super(color, marca, modelo, marcaRadio);
        new Radio(marcaRadio);
    }

    public AutoNuevo(String color, String marca, String modelo, float precio, String marcaRadio) {
        super(color, marca, modelo, precio, marcaRadio);
        new Radio(marcaRadio);
    }

}
