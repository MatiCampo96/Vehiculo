package ar.org.centro8.curso.java.entities;

public class AutoClasico extends Vehiculo {

    // CONSTRUCTORES SIN RADIO
    public AutoClasico(String color, String marca, String modelo) {
        super(color, marca, modelo);
    }

    public AutoClasico(String color, String marca, String modelo, float precio) {
        super(color, marca, modelo, precio);
    }

    // CONSTRUCTORES CON RADIO
    public AutoClasico(String color, String marca, String modelo, String marcaRadio) {
        super(color, marca, modelo, marcaRadio);
        new Radio(marcaRadio);
    }

    public AutoClasico(String color, String marca, String modelo, float precio, String marcaRadio) {
        super(color, marca, modelo, precio, marcaRadio);
        new Radio(marcaRadio);
    }

}
