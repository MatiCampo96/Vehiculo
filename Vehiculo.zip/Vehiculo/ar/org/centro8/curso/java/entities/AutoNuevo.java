package ar.org.centro8.curso.java.entities;

public class AutoNuevo extends Vehiculo {
    private Radio radio;

    public void cambiarRadio(String marcaRadio) {
        radio = new Radio(marcaRadio);
    }

    public AutoNuevo(String color, String marca, String modelo, String radio) {
        super(color, marca, modelo, radio);
    }

    public AutoNuevo(String color, String marca, String modelo, float precio, String radio) {
        super(color, marca, modelo, precio, radio);
    }

}
    