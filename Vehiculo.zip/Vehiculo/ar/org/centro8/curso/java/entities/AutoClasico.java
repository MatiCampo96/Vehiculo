package ar.org.centro8.curso.java.entities;

public class AutoClasico extends Vehiculo {
    Radio radio;

    // CONSTRUCTORES SIN RADIO
    public AutoClasico(String color, String marca, String modelo) {
        super(color, marca, modelo);
    }

    public AutoClasico(String color, String marca, String modelo, float precio) {
        super(color, marca, modelo, precio);
    }
    // CONSTRUCTORES CON RADIO
    public AutoClasico(String color, String marca, String modelo, String radio) {
        super(color, marca, modelo, radio);
    }

    public AutoClasico(String color, String marca, String modelo, float precio, String radio) {
        super(color, marca, modelo, precio, radio);
    }

}
