package ar.org.centro8.curso.java.entities;

public class AutoClasico extends Vehiculo{
    Radio radio;

    //CONSTRUCTORES SIN RADIO
    public AutoClasico(String color, String marca, String modelo) {
        super(color, marca, modelo);
    }
    public AutoClasico(String color, String marca, String modelo, float precio) {
        super(color, marca, modelo, precio);
    }
    public void agregarRadio(String marcaRadio){
        radio = new Radio(marcaRadio);
    }
    //CONSTRUCTORES CON RADIO
    public AutoClasico(String color, String marca, String modelo, Radio radio) {
        super(color, marca, modelo, radio);
    }
    public AutoClasico(String color, String marca, String modelo, float precio, Radio radio) {
        super(color, marca, modelo, precio, radio);
    }
    
}
