package ar.org.centro8.curso.java.test;
import ar.org.centro8.curso.java.entities.AutoClasico;
import ar.org.centro8.curso.java.entities.AutoNuevo;
import ar.org.centro8.curso.java.entities.Radio;
import ar.org.centro8.curso.java.entities.Vehiculo;

public class TestVehiculos {
    public static void main(String[] args) {
        //Radio radio1 = new Radio("Mitre");
        //Radio radio2 = new Radio("JBL");
        System.out.println("Proyecto vehiculos");
        System.out.println("----- AutoClasico creado sin radio -----");
        AutoClasico auto1 = new AutoClasico("Rosa", "VW", "Porche");
        System.out.println(auto1.toString());
        System.out.println("----- Le agregue una radio al mismo auto -----");
        auto1.setRadio("JBL");
        System.out.println(auto1.toString());
        System.out.println("----- AutoClasico creado con radio -----");
        AutoClasico auto2 = new AutoClasico("Peugeot", "Mandarina", "Titan", "Sony");
        System.out.println(auto2.toString());
        System.out.println("----- AutoClasico con precio, sin radio -----");
        AutoClasico auto3 = new AutoClasico("Gris", "VW", "208", 100000);
        System.out.println(auto3.toString());
        System.out.println("----- AutoClasico con precio y radio -----");
        AutoClasico auto4 = new AutoClasico("Yamaha", "Honda", "YBR", 50000, "Panasonic");
        System.out.println(auto4.toString());
        System.out.println("----- AutoNuevo con precio y radio -----");
        AutoNuevo auto5 = new AutoNuevo("Marron", "Miller", "Torino", 10000, "JSA");
        System.out.println(auto5.toString());
        System.out.println("----- Le cambio la radio al AutoNuevo-----");
        auto5.setRadio("JSA2");
        System.out.println(auto5.toString());
        System.out.println("----- AutoNuevo sin precio y con radio -----");
        AutoNuevo auto6 = new AutoNuevo("Morado", "VW", "Vento", "JASPEN");
        System.out.println(auto6.toString());
        auto1.setColor("Morado");
        System.out.println(auto1.getRadio()); 
        System.out.println(auto1.getColor());
        /*
         * NO SE PERMITE CREAR UN AUTO NUEVO SIN RADIO
         * System.out.println("----- Prueba AutoNuevo SIN radio -----");
         * AutoNuevo auto7=new AutoNuevo("Rojo", "Toyota", "Corolla");
         * System.out.println(auto7.toString());
         */
        
       /*0  try {AutoNuevo auto7=new AutoNuevo("Rojo", "BMW", "2.0");
            
        } catch (Exception e) {
            System.out.println("No se puede crear un AutoNuevo sin radio");
        }
        */
    }

}
