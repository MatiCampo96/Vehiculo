package ar.org.centro8.curso.java.entities;

public class Radio {
    String marcaRadio;

    public Radio(String marcaRadio) {
        this.marcaRadio = marcaRadio;
    }

    public String getRadio() {
        return marcaRadio;
    }

    public void setRadio(String marcaRadio) {
        this.marcaRadio = marcaRadio;
    }

    @Override
    public String toString() {
        return "Radio [marcaRadio=" + marcaRadio + "]";
    }

}
